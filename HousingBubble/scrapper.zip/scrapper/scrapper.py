# coding: utf-8
from bs4 import BeautifulSoup
import urllib2
from time import sleep
import sys
import utility
import house
import signal
"""
start_url = "https://www.zillow.com/homes/for_rent/Champaign-IL-61820/house,condo," \
            "apartment_duplex,mobile,townhouse_type/85172_rid/40.162411,-88.180819,40.067102,-88.304415_rect/12_zm/"

urls = list();
urls.append(start_url)
idx = 0

house_urls = list()
# main loop
while True:
    sleep(0.5)
    if idx >= len(urls):
        break;
    url = urls[idx]
    print "url to be opened is "+url
    idx+=1
    try:
        response = urllib2.urlopen(url)
    except ValueError:
        sys.exit()
    except urllib2.HTTPError:
        sys.exit()

    soup = BeautifulSoup(response.read(), 'html.parser')
    utility.scrape_for_house(soup, house_urls)

    next_page = utility.find_next_page(soup)

    if next_page is None:
        break
    else:
        urls.append(next_page)

print len(house_urls)

file = open("urls", "w")

for house_url in house_urls:
    file.write(house_url)
    file.write("\n")
"""

file = open("urls", "r")

house_urls = list()

for line in file:
    house_urls.append(line[0:-1])

final_result = list()

houses_csv = open("houses.csv", "a")
global count
count_file = open("count.file", "r+")
count = int(count_file.read())
for i in range(count, len(house_urls)):
    house_url = house_urls[i]
    sleep(0.3)
    house_url = "https://www.zillow.com" + house_url
    print "scraping " + house_url
    try:
        response = urllib2.urlopen(house_url)
    except ValueError, urllib2.HTTPError:
        sys.exit()
    html = response.read()
    soup = BeautifulSoup(html, 'html.parser')
    houses = utility.get_room_bbp(soup)
    if len(houses) == 0:
        houses.append(house.house())
    for curr_house in houses:
        utility.get_address_and_image(soup, curr_house)
        utility.get_room_bbp_2(soup, curr_house)
        utility.get_room_info(soup, curr_house)
        utility.get_room_info2(soup, curr_house)
        final_result.append(curr_house)
        utility.regular_match_coordinate(html, curr_house)
        curr_house.print_house()
        curr_house.write_to_file(houses_csv)
    count_file.seek(0,0)
    count_file.write(str(i+1))

for elem in final_result:
    elem.print_house()

'''
pseudo code

while next_page:
    open url
    for all housing link in this page:
        open the housing link and read information
        store as class
    get next_page

'''
