# coding: utf-8
from bs4 import BeautifulSoup
import re
import house


# those are helper functions that extract all kinds of data from html text 


def get_address_and_image(soup_, house_):
    addr = soup_.find('input', {'id':'saddr', 'name':'saddr'})
    if addr is not None:
        house_.set_address(addr['value'])
        return
    addr = soup_.find('meta', {'property' : 'og:zillow_fb:address'})
    if addr is not None:
        house_.set_address(addr['content'])
        return
    addr = soup_.find('meta', {'property' : 'og:title'})
    if addr is not None:
        house_.set_address(addr['content'])
        return
    image = soup_.find('meta', {'property' : 'og:image'})
    if image is not None:
        house_.set_image(image['content'])
    price = soup_.find('meta', {'property': 'product:price:amount'})
    if price is not None:
        house_.set_price(int(float(price['content'])))


def find_next_page(soup_):
    href = soup_.find('link', {'rel' : 'next'})
    if href is None:
        return None
    next_url = href.get('href')
    return next_url


def scrape_for_house(soup_, houses_):
    links = soup_.find_all('a', {'href': re.compile('\A/homedetails/')})
    for elem in links:
        houses_.append(elem.get("href"))
    links = soup_.find_all('a', {'href': re.compile('\A/b/')})
    for elem in links:
        houses_.append(elem.get("href"))


def get_room_bbp(soup_):
    rooms = soup_.find_all('span', {'class':"floorplan-title"})
    houses = list()
    unit_prices = soup_.find_all('span', {'class': 'floorplan-unit-price'})
    idx_ = 0
    for room in rooms:
        price = "?"
        unit_price = 500
        try:
            price = room.find('strong').text.encode("utf-8")
        except AttributeError:
            print "price error: get_room_bbp didn't find floorplan-title: strong"
        try:
            price = int(re.sub(r"[a-z+$,]", "", price))
        except (TypeError, ValueError, NameError):
            print "price error get_room_bbp " + price
            price = 500

        if idx_ < (len(unit_prices)):
            unit_price = unit_prices[idx_].text.encode("utf-8")
            try:
                unit_price = int(re.sub(r"[a-z$, ]", "", unit_price))
            except (TypeError, ValueError, NameError):
                unit_price = 500

        bedrooms = "?"
        try:
            bedrooms = room.find('span', {'class': 'hide-xs'}).text.encode("utf-8")
        except AttributeError:
            print "bedroom error: get_room_bbp didn't find span class: hide-xs "
        try:
            bedrooms = float(re.sub(r"[a-z· ]", "", bedrooms))
        except (TypeError, ValueError, NameError):
            print "bedroom error get_room_bbp " + bedrooms
            bedrooms = 1
        bathrooms = "?"
        try:
            bathrooms = room.find('span', {'class': 'short-ba'}).text.encode("utf-8")
        except AttributeError:
            print "bathroom error: get_room_bbp didn't find span class: short-ba"
        try:
            bathrooms = float(re.sub(r"[a-z· ]", "", bathrooms))
        except (TypeError, ValueError, NameError):
            print "bathroom error get_room_bbp " + bathrooms
            bathrooms = 1
        area = room.text.encode("utf-8")
        idx = area.find("sqft")
        area = area[max(idx-7, 0):]
        try:
            area = int(re.sub(r"[a-z, ·]", "", area))
        except (TypeError, ValueError, NameError):
            print "area error: get_room_bbp " + area
            area = 1000
        house_ = house.house()
        house_.set_price(price)
        house_.set_price(unit_price)
        house_.set_bedrooms(bedrooms)
        house_.set_bathrooms(bathrooms)
        house_.set_area(area)
        houses.append(house_)
        idx_ += 1
    return houses


def get_room_info(soup_, house_):
    # method 1
    features = soup_.find_all('span', {'class':'feature-text'})
    for elem in features:
        house_.process_info(elem.text.encode('utf-8'))


def get_room_bbp_2(soup_, house_):
    infos = soup_.find_all('span', {'class': 'addr_bbs'})
    for info in infos:
        text = info.text.encode("utf-8").lower()
        if text.find("bed") > -1:
            try:
                bedrooms = float(re.sub(r"[a-z ,$+]", "", text))
            except (TypeError, ValueError, NameError):
                print "error: get_room_bbp_2 " + text
                bedrooms = 1
            house_.set_bedrooms(bedrooms)
        elif text.find("bath") > -1:
            try:
                bathrooms = float(re.sub(r"[a-z ,$+]", "", text))
            except (TypeError, ValueError, NameError):
                print "error: get_room_bbp_2 " + text
                bathrooms = 1
            house_.set_bathrooms(bathrooms)
        elif text.find("sqft") > -1:
            try:
                area = int(re.sub(r"[a-z, $+]", "", text))
            except (TypeError, ValueError, NameError):
                print "error: get_room_bbp_2 " + text
                area = 1000
            house_.set_area(area)
    price = soup_.find_all('div', {'class':['main-row', 'home-summary-row']})
    for elem in price:
        text = elem.text.encode("utf-8").lower()
        try:
            rent = int(re.sub(r"[a-z ,$+./]", "", text))
        except (TypeError, ValueError, NameError):
            print "error: get_room_bbp_2 " + text
            rent = 500
        house_.set_price(rent)


def get_room_info2(soup_, house_):
    infos = soup_.find_all('ul', {'class': ['zsg-list_square', 'zsg-lg-1-3', 'zsg-md-1-2', 'zsg-sm-1-1']})
    for info in infos:
        entries = info.find_all('li')
        for entry in entries:
            house_.process_info(entry.text)


def regular_match_coordinate(html, house_):
    lat = re.search('40.(\d{6}|\d{5})', html)
    long = re.search('-88.(\d{6}|d{5})', html)
    house_.set_lat(lat.group(0))
    house_.set_long(long.group(0))