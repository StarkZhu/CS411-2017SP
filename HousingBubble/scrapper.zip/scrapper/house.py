import json


class house:
    pid = 1
    pid_file = open("house.count", "r+")
    house_map = dict()
    def __init__(self, price_=500, bedrooms_=1, bathrooms_=1, area_=1000,
                 floor_=1, year_=1960, parking_=0, washer_=0, dryer_=0, ac_=0, utility_=0,
                 pet_=0, address_=None, owner_=None, lat_=None, long_=None, image_=None):
        self.price = price_
        self.bedrooms = bedrooms_
        self.bathrooms = bathrooms_
        self.area = area_
        self.floor = floor_
        self.year = year_
        self.parking = parking_
        self.washer = washer_
        self.dryer = dryer_
        self.ac = ac_
        self.utility = utility_
        self.pet = pet_
        self.address = address_
        self.owner = owner_
        self.lat = lat_
        self.long = long_
        self.image = image_

    def process_info(self, text):
        text = text.lower()
        if text.find('dogs') > -1 or text.find('cats') > -1:
            print text
            self.pet = 1
        if text.find('pets: no') > -1 or text.find('no pet') > -1:
            print text
            self.pet = 0
        if text.find('cooling') > -1:
            self.ac = 1
        if text.find('heating') > -1:
            self.ac = 1
        if text.find('a/c'):
            self.ac = 1
        if text.find('parking') > -1:
            self.parking = 1
        if text.find('wash') > -1 and text.find('dishwasher') == -1:
            self.washer = 1
        if text.find('dryer') > -1:
            self.dryer = 1
        if text.find('laundry: in unit') >-1:
            self.washer = 1
            self.dryer = 1
        if text.find('laundry: shared') > -1:
            self.washer = 1
            self.dryer = 1
        if text.find('fixed rate'):
            self.utility = 1
        if text.find('{') > -1 and text.find('}') > -1:
            infos = json.loads(text)
            if "targets" in infos.keys():
                target = infos['targets']
                if 'mlat' in target.keys():
                    self.lat = float(target['mlat'])
                if 'mlong' in target.keys():
                    self.long = float(target['mlong'])
                if 'aamgnrc1' in target.keys():
                    self.set_address(target['aamgnrc1'])
                if 'z_listing_image_url' in target.keys():
                    self.set_image(target['z_listing_image_url'])
        return

    def set_address(self, address_):
        if self.address is None:
            self.address = address_

    def set_price(self, price_):
        if self.price is None or self.price == 500:
            self.price = price_

    def set_bedrooms(self, bedrooms_):
        if self.bedrooms == 1:
            self.bedrooms = bedrooms_

    def set_bathrooms(self, bathrooms_):
        if self.bathrooms == 1:
            self.bathrooms = bathrooms_

    def set_area(self, area_):
        if self.area is None or self.area == 1000:
            self.area = area_

    def set_image(self, image_):
        if self.image is None:
            self.image = image_

    def set_lat(self, lat_):
        if self.lat is None:
            self.lat = float(lat_)

    def set_long(self, long_):
        if self.long is None:
            self.long = float(long_)

    def print_house(self):
        print "price: " + str(self.price) + \
            " bedrooms: " + str(self.bedrooms) + \
            " bathrooms: " + str(self.bathrooms) + \
            " area: " + str(self.area) + \
            " floor: " + str(self.floor) + \
            " year: " + str(self.year) + \
            " parking " + str(self.parking) + \
            " washer: " + str(self.washer) + \
            " dryer: " + str(self.dryer) + \
            " ac: " + str(self.ac) + \
            " utility: " + str(self.utility) + \
            " pet: " + str(self.pet) + \
            " address: " + str(self.address) + \
            " owner: " + str(self.owner) + \
            " lat: " + str(self.lat) + \
            " long: " + str(self.long) + \
            " image: " + str(self.image)

    def write_to_file(self, file_):
        house.pid_file.seek(0,0)
        house.pid = int(house.pid_file.read())
        self.address = self.address.replace(',', '')
        wash_dry = 0
        if self.washer == 1 and self.dryer == 1:
            wash_dry = 1
        to_be_written = str(house.pid) + \
            "," + str(self.price) + \
            "," + str(self.bedrooms) + \
            "," + str(self.bathrooms) + \
            "," + str(self.area) + \
            "," + str(self.parking) + \
            "," + str(wash_dry) + \
            "," + str(self.ac) + \
            "," + str(self.pet) + \
            "," + str(self.lat) + \
            "," + str(self.long) + \
            "," + str(self.address) + \
            "," + str(self.owner) + \
            ",\"" + str(self.image) + '"\n';
        idx = to_be_written.find(",")
        if to_be_written[idx:] in house.house_map.keys():
            return
        house.house_map[to_be_written[idx:]] = 1
        file_.write(to_be_written)
        house.pid += 1
        house.pid_file.seek(0.0)
        house.pid_file.write(str(house.pid))
