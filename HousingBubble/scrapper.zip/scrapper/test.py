from bs4 import BeautifulSoup
import urllib2
import utility
import house
import re

url = "https://www.zillow.com/b/606-S-Prairie-Champaign-IL/40.109577,-88.248038_ll/"
response = urllib2.urlopen(url)

data = response.read()
#print data

soup = BeautifulSoup(data, 'html.parser')
#response.seek(0,0)


utility.get_room_bbp_2(soup, house.house())


# utility.get_room_info(soup)
#f = open("test.html", "w")
#data = f.read()
#f.write(soup.prettify().encode("utf-8"))
#results = soup.findAll(re.compile("40.1"))
houses = utility.get_room_bbp(soup)
#print results
for house in houses:
    house.print_house()
